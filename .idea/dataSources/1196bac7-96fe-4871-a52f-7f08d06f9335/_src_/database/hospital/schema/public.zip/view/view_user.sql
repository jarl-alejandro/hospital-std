CREATE VIEW view_user AS SELECT hgc_profesionales.hgc_codi_profe,
    hgc_profesionales.hgc_cedu_profe,
    hgc_profesionales.hgc_nom_profe,
    hgc_profesionales.hgc_ape_profe,
    hgc_profesionales.hgc_celu_profe,
    hgc_profesionales.hgc_tele_profe,
    hgc_profesionales.hgc_direc_profe,
    hgc_profesionales.hgc_dni_profe,
    hgc_profesionales.hgc_emai_profe,
    hgc_profesionales.hgc_fecn_profe,
    hgc_profesionales.hgc_profe_profe,
    hgc_profesionales.hgc_sexo_profe,
    hgc_usuario.hgc_rol_usu,
    hgc_profesionales.hgc_avat_profe,
    hgc_usuario.hgc_user_usu
   FROM (hgc_usuario
     JOIN hgc_profesionales ON (((hgc_usuario.hgc_codi_usu)::text = (hgc_profesionales.hgc_cedu_profe)::text)));
