CREATE VIEW view_paciente AS SELECT hgc_paciente.hgc_codi_pacie,
    hgc_paciente.hgc_cedu_pacie,
    (((hgc_paciente.hgc_nom_pacie)::text || ' '::text) || (hgc_paciente.hgc_ape_pacie)::text) AS paciente,
    hgc_paciente.hgc_celu_pacie,
    hgc_paciente.hgc_tele_pacie,
    hgc_paciente.hgc_direc_pacie,
    hgc_paciente.hgc_dni_pacie,
    hgc_paciente.hgc_emai_pacie,
    hgc_paciente.hgc_fecn_pacie,
    hgc_paciente.hgc_sexo_pacie,
    hgc_hclinica.hgc_histo_hcli
   FROM (hgc_hclinica
     JOIN hgc_paciente ON (((hgc_hclinica.hgc_histo_hcli)::text = (hgc_paciente.hgc_cedu_pacie)::text)));
