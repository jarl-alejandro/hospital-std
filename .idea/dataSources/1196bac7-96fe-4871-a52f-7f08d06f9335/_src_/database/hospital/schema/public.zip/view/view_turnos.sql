CREATE VIEW view_turnos AS SELECT hgc_turno.hgc_id_turno,
    hgc_turno.hgc_paci_turno,
    hgc_turno.hgc_doct_turno,
    hgc_turno.hgc_esta_turno,
    hgc_turno.hgc_fech_turno,
    hgc_turno.hgc_hini_turno,
    hgc_turno.hgc_fin_turno,
    view_paciente.paciente,
    (((view_user.hgc_nom_profe)::text || ''::text) || (view_user.hgc_ape_profe)::text) AS doctor,
    view_paciente.hgc_fecn_pacie
   FROM ((hgc_turno
     JOIN view_paciente ON (((hgc_turno.hgc_paci_turno)::text = (view_paciente.hgc_cedu_pacie)::text)))
     JOIN view_user ON ((hgc_turno.hgc_doct_turno = view_user.hgc_codi_profe)));
